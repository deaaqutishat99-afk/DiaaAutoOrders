package com.diaa.autoorders

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("orders", MODE_PRIVATE) }
    private lateinit var listBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (18 * resources.displayMetrics.density).toInt()
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        page.addView(TextView(this).apply {
            text = "Diaa Auto Orders"
            textSize = 25f
            gravity = Gravity.CENTER
        }, match())
        page.addView(TextView(this).apply {
            text = "أضف أسماء المتاجر التي تريد قبول طلباتها فقط."
            textSize = 16f
            setPadding(0, pad, 0, pad)
        })
        val input = EditText(this).apply {
            hint = "اسم المتجر"
            singleLine = true
        }
        page.addView(input, match())
        page.addView(Button(this).apply {
            text = "إضافة متجر"
            setOnClickListener {
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    val stores = getStores().toMutableSet()
                    stores.add(name)
                    saveStores(stores)
                    input.text.clear()
                    renderStores()
                }
            }
        }, match())
        page.addView(TextView(this).apply {
            text = "المتاجر المسموح بها"
            textSize = 18f
            setPadding(0, pad, 0, 8)
        })
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(listBox, match())
        page.addView(Button(this).apply {
            text = "تفعيل خدمة الوصول"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, match())
        page.addView(TextView(this).apply {
            text = "مهم: اترك قائمة المتاجر فارغة إذا لم ترد قبول أي طلب. الخدمة لا تقبل إلا عند العثور على اسم متجر مطابق وزر «قبول» ظاهر."
            textSize = 13f
            setPadding(0, pad, 0, 0)
        }, match())
        setContentView(page)
        renderStores()
    }

    private fun getStores(): Set<String> = prefs.getStringSet("stores", emptySet())?.toSet() ?: emptySet()
    private fun saveStores(stores: Set<String>) { prefs.edit().putStringSet("stores", stores).apply() }

    private fun renderStores() {
        listBox.removeAllViews()
        val stores = getStores().sorted()
        if (stores.isEmpty()) {
            listBox.addView(TextView(this).apply { text = "لا توجد متاجر مضافة حالياً."; textSize = 14f })
        }
        stores.forEach { name ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(TextView(this).apply {
                text = name
                textSize = 16f
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply {
                text = "حذف"
                setOnClickListener {
                    saveStores(getStores() - name)
                    renderStores()
                }
            })
            listBox.addView(row)
        }
    }

    private fun match() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
