package com.diaa.autoorders

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class OrderAccessibilityService : AccessibilityService() {
    private val prefs by lazy { getSharedPreferences("orders", MODE_PRIVATE) }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val allowed = prefs.getStringSet("stores", emptySet())?.toList().orEmpty()
        if (allowed.isEmpty()) return

        val root = rootInActiveWindow ?: return
        val visibleText = collectText(root).joinToString(" ")
        val normalized = normalize(visibleText)

        // Do not act unless a configured merchant name is visibly present.
        val matchedStore = allowed.firstOrNull { normalize(it).isNotBlank() && normalized.contains(normalize(it)) } ?: return

        val orderId = Regex("#\\s*([A-Za-z0-9-]+)").find(visibleText)?.groupValues?.getOrNull(1)
        if (orderId != null && prefs.getString("last_accepted_order", null) == orderId) return

        val acceptNode = findAcceptNode(root) ?: return
        val clicked = clickNodeOrParent(acceptNode)
        if (clicked && orderId != null) {
            prefs.edit().putString("last_accepted_order", orderId).putString("last_store", matchedStore).apply()
        }
    }

    private fun normalize(value: String): String =
        value.lowercase(Locale.ROOT).replace(Regex("\\s+"), " ").trim()

    private fun collectText(node: AccessibilityNodeInfo): List<String> {
        val result = mutableListOf<String>()
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let(result::add)
        node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let(result::add)
        for (i in 0 until node.childCount) node.getChild(i)?.let { result.addAll(collectText(it)) }
        return result
    }

    private fun findAcceptNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val label = normalize(node.text?.toString().orEmpty() + " " + node.contentDescription?.toString().orEmpty())
        if (label == "قبول" || label.contains("قبول")) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findAcceptNode(child)
            if (found != null) return found
        }
        return null
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        repeat(5) {
            if (current == null) return false
            if (current!!.isClickable && current!!.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            current = current!!.parent
        }
        return false
    }

    override fun onInterrupt() = Unit
}
