plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.diaa.autoorders"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.diaa.autoorders"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
